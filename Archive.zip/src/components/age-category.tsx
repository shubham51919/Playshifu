import Link from "next/link"

interface AgeCategoryProps {
    age: string
    color: string
    textColor: string
}

export default function AgeCategory({ age, color, textColor }: AgeCategoryProps) {
    return (
        <Link
            href={`/age/${age}`}
            className={`${color} ${textColor} rounded-[8px] px-6 py-3 text-xs font-medium whitespace-nowrap`}
        >
            {age} yrs
        </Link>
    )
}
