"use client"
import { useState, useEffect } from 'react';
import Image from 'next/image';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function ToyShopCarousel() {
    const [currentSlide, setCurrentSlide] = useState(0);

    const slides = [
        {
            title: "Power up your child's skills with our super toys",
            buttonText: "Shop now",
            color: "bg-yellow-300", // Yellow background
            image: "/images/banner2.png",
            imageAlt: "Colorful educational toys"
        },
        {
            title: "STEM toys that make learning fun",
            buttonText: "Explore STEM",
            color: "bg-blue-200", // Light blue background
            image: "/images/banner2.png",
            imageAlt: "Science and robotics kits"
        },
        {
            title: "Sensory toys for development",
            buttonText: "Discover more",
            color: "bg-green-200", // Light green background
            image: "/images/banner2.png",
            imageAlt: "Sensory toys collection"
        },
        {
            title: "New arrivals: Spring collection",
            buttonText: "See what's new",
            color: "bg-pink-200", // Light pink background
            image: "/images/banner2.png",
            imageAlt: "New spring toys"
        }
    ];

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
        }, 5000);
        return () => clearInterval(interval);
    }, [slides.length]);

    const nextSlide = () => {
        setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    };

    const prevSlide = () => {
        setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
    };

    return (
        <div className="flex flex-col gap-2">
            {/* Carousel slider */}
            <div className="relative h-[30vh] sm:h-[40vh] md:h-[50vh] lg:h-[60vh] overflow-hidden rounded-lg">
                {slides.map((slide, index) => (
                    <div
                        key={index}
                        style={{ backgroundImage: `url(${slide.image})`, backgroundPosition: "center", backgroundSize: "cover" }}
                        className={`absolute top-0 left-0 w-full h-full transition-opacity duration-500 ease-in-out ${currentSlide === index ? 'opacity-100' : 'opacity-0 pointer-events-none'
                            } ${slide.color} px-4 py-3 flex items-center`}
                    >
                        {/* <div className="w-full md:w-1/2 relative left-0 sm:left-[10%] md:left-[30%] lg:left-[65%] top-0 sm:top-[10%] md:top-[25%] flex flex-col items-center md:items-start">
                            <button className="bg-orange-500 hover:bg-orange-600 text-white text-xs sm:text-sm rounded-full px-3 sm:px-4 py-1 h-7 sm:h-8">
                                {slide.buttonText}
                            </button>
                        </div> */}
                    </div>
                ))}

                {/* Navigation buttons */}
                <button
                    onClick={prevSlide}
                    className="absolute left-1 sm:left-2 top-1/2 -translate-y-1/2 bg-white bg-opacity-70 p-1 rounded-full hover:bg-opacity-100 transition-all"
                    aria-label="Previous slide"
                >
                    <ChevronLeft size={16} className="sm:w-5 sm:h-5" />
                </button>
                <button
                    onClick={nextSlide}
                    className="absolute right-1 sm:right-2 top-1/2 -translate-y-1/2 bg-white bg-opacity-70 p-1 rounded-full hover:bg-opacity-100 transition-all"
                    aria-label="Next slide"
                >
                    <ChevronRight size={16} className="sm:w-5 sm:h-5" />
                </button>
            </div>

            {/* Indicator dots - now outside the slider */}
            <div className="flex justify-center space-x-1 sm:space-x-2 mt-1">
                {slides.map((_, index) => (
                    <button
                        key={index}
                        onClick={() => setCurrentSlide(index)}
                        className={`h-1.5 sm:h-2 rounded-full transition-all ${currentSlide === index ? 'bg-[#822382] w-2 sm:w-2' : ' border border-[#822382] w-1.5 sm:w-2'
                            }`}
                        aria-label={`Go to slide ${index + 1}`}
                    />
                ))}
            </div>
        </div>
    );
}