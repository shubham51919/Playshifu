"use client"
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Play } from 'lucide-react';

export default function MediaFeatureSection() {
    const [currentMediaIndex, setCurrentMediaIndex] = useState(0);

    const mediaFeatures = [
        {
            id: 1,
            videoThumbnail: "/images/videoThumbnail.png",
            title: "AS SEEN ON",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed dui tortor, fringilla ac mi quis",
            networks: ["FOX11", "NBC"]
        },
        {
            id: 2,
            videoThumbnail: "/images/videoThumbnail.png",
            title: "AS SEEN ON",
            description: "Another featured video with different content showcasing our educational toys",
            networks: ["ABC", "CNN"]
        },
        {
            id: 3,
            videoThumbnail: "/images/videoThumbnail.png",
            title: "FEATURED IN",
            description: "Watch our toys being demonstrated on this popular morning show",
            networks: ["CBS", "ESPN"]
        }
    ];

    const nextMedia = () => {
        setCurrentMediaIndex((prevIndex) => (prevIndex + 1) % mediaFeatures.length);
    };

    const prevMedia = () => {
        setCurrentMediaIndex((prevIndex) =>
            prevIndex === 0 ? mediaFeatures.length - 1 : prevIndex - 1
        );
    };

    const currentMedia = mediaFeatures[currentMediaIndex];

    return (
        <div className=" py-12 px-4 max-w-7xl mx-auto">
            <div className="absolute max-w-7xl mx-auto">

                <button
                    onClick={prevMedia}
                    className="relative left-[-5%] top-[25%]  bg-white rounded-full p-2 shadow-md"
                    aria-label="Previous media"
                >
                    <ChevronLeft size={24} />
                </button>
                {/* <button
                    onClick={nextMedia}
                    className="relative  right-0 top-[25%] z-10 bg-white rounded-full p-2 shadow-md"
                    aria-label="Next media"
                >
                    <ChevronRight size={24} />
                </button> */}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center mb-12">
                {/* Left side - Video with play button */}
                <div className="relative rounded-lg overflow-hidden shadow-lg">
                    <img
                        src={currentMedia.videoThumbnail}
                        alt="Media feature"
                        className="w-full h-auto"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                        <button
                            className="bg-red-500 hover:bg-red-600 text-white rounded-full p-4 transition-colors duration-300"
                            aria-label="Play video"
                        >
                            <Play size={32} />
                        </button>
                    </div>

                    {/* Navigation arrows */}



                </div>

                {/* Right side - AS SEEN ON section */}
                <div className="space-y-6">
                    <h2 className="text-3xl font-bold text-gray-700">{currentMedia.title}</h2>

                    <div className="flex items-center gap-4">
                        <div className="text-5xl font-black">
                            FOX<span className="text-black">11</span>
                        </div>
                        <span className="text-purple-700 text-3xl">&</span>
                        <div>
                            <svg viewBox="0 0 160 80" className="h-12 w-32">
                                <path d="M25,64L0,36L25,8L50,36L25,64Z" fill="currentColor" className="text-red-500" />
                                <path d="M50,64L25,36L50,8L75,36L50,64Z" fill="currentColor" className="text-yellow-500" />
                                <path d="M75,64L50,36L75,8L100,36L75,64Z" fill="currentColor" className="text-green-500" />
                                <path d="M100,64L75,36L100,8L125,36L100,64Z" fill="currentColor" className="text-blue-500" />
                                <path d="M125,64L100,36L125,8L150,36L125,64Z" fill="currentColor" className="text-purple-500" />
                                <text x="130" y="55" className="text-4xl font-black" fill="black">NBC</text>
                            </svg>
                        </div>
                    </div>

                    <p className="text-lg text-gray-600">
                        {currentMedia.description}
                    </p>
                </div>
            </div>

            {/* Brand logos section */}
            <div className="mt-16">
                <div className="flex flex-wrap justify-center items-center gap-4 md:gap-8 lg:gap-12 opacity-70">
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="Forbes" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="Wired" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="BuzzFeed" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="Parents" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="Fortune" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="Inc" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="VentureBeat" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="World Economic Forum" className="h-full w-full object-contain" />
                    </div>
                    <div className="h-12 w-24">
                        <img src="/images/featuredSub.png" alt="Business Insider" className="h-full w-full object-contain" />
                    </div>
                </div>
            </div>

        </div>
    );
}