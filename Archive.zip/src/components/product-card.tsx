import Image from "next/image";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ProductCardProps {
    image: string;
    title: string;
    price: number;
    salePrice: number;
    rating?: number;
    discount?: string;
}

export default function ProductCard({
    image,
    title,
    price,
    salePrice,
    rating,
    discount,
}: ProductCardProps) {
    return (
        <div className="bg-white rounded-lg overflow-hidden">
            <div className="relative">
                {discount && (
                    <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">
                        {discount}
                    </Badge>
                )}
                <Image
                    src={image || "/placeholder.svg"}
                    alt={title}
                    width={150}
                    height={300}
                    className="w-full h-[350px] rounded-[30px] object-contain p-2"
                />
                {rating && (
                    <div className=" px-3 py-2 absolute bottom-12 right-3 bg-white rounded-[40px] hover:bg-white-600 flex items-center">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs ml-1">{rating}</span>
                    </div>
                )}
            </div>
            <div className="p-3">
                <div className="flex justify-between items-start mb-1">
                    <div className="flex gap-4 items-center">
                        <p className="text-green-900 font-bold text-lg ">
                            Now ${price.toFixed(2)}
                        </p>
                        <p className="font-bold text-sm text-gray-400 line-through">
                            ${salePrice.toFixed(2)}
                        </p>
                    </div>

                </div>
                <h3 className="font-medium text-sm mb-2">{title}</h3>
                <p className="text-xs text-gray-500 mb-2">
                    A wonderful educational toy for children of all ages
                </p>
                <Button className="w-full text-xs text-black h-8 bg-[rgb(244,217,102)] hover:bg-[rgb(260,217,102)]">
                    Add to Cart
                </Button>
            </div>
        </div>
    );
}
