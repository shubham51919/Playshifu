"use client"
import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function TestimonialCarousel() {
    const [currentIndex, setCurrentIndex] = useState(0);

    const testimonials = [
        {
            id: 1,
            image: "/images/review1.png",
            username: "@reddysameera",
            text: "just got the best Diwali gift for her son! What are you waiting for?es."
        },
        {
            id: 2,
            image: "/images/review1.png",
            username: "@reddysameera",
            text: "just got the best Diwali gift for her son! What are you waiting for?es."
        },
        {
            id: 3,
            image: "/images/review1.png",
            username: "@reddysameera",
            text: "just got the best Diwali gift for her son! What are you waiting for?es."
        },
        {
            id: 4,
            image: "/images/review1.png",
            username: "@reddysameera",
            text: "just got the best Diwali gift for her son! What are you waiting for?es."
        }
    ];

    const visibleTestimonials = () => {
        // For mobile, show 1, for tablet 2, for desktop 4
        const isMobile = window.innerWidth < 640;
        const isTablet = window.innerWidth >= 640 && window.innerWidth < 1024;

        const visibleCount = isMobile ? 1 : isTablet ? 2 : 4;

        let items = [];
        for (let i = 0; i < visibleCount; i++) {
            const index = (currentIndex + i) % testimonials.length;
            items.push(testimonials[index]);
        }
        return items;
    };

    const nextSlide = () => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    };

    const prevSlide = () => {
        setCurrentIndex((prevIndex) =>
            prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
        );
    };

    return (
        <div className="w-full">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">What kids, parents and teaches love</h2>

            <div className="relative">
                <div className="flex justify-between items-center">
                    <button
                        onClick={prevSlide}
                        className="absolute left-0 z-10 bg-white rounded-full p-2 shadow-md"
                        aria-label="Previous testimonial"
                    >
                        <ChevronLeft size={24} />
                    </button>

                    <div className="flex gap-4 overflow-hidden mx-12">
                        {testimonials.map((testimonial, index) => (
                            <div
                                key={testimonial.id}
                                className={`flex-none w-full sm:w-1/2 md:w-1/3 lg:w-1/4 p-2 transition-opacity duration-300 ${index >= currentIndex && index < currentIndex + 4 ? 'opacity-100' : 'opacity-0 hidden'
                                    }`}
                            >
                                <div className="bg-gray-100 rounded-lg overflow-hidden shadow-md">
                                    <img
                                        src={testimonial.image}
                                        alt="Testimonial"
                                        className="w-full h-48 object-cover"
                                    />
                                    <div className="p-3">
                                        <span className="text-purple-600 font-medium">{testimonial.username}</span>
                                        <p className="text-gray-700 text-sm mt-1">{testimonial.text}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    <button
                        onClick={nextSlide}
                        className="absolute right-0 z-10 bg-white rounded-full p-2 shadow-md"
                        aria-label="Next testimonial"
                    >
                        <ChevronRight size={24} />
                    </button>
                </div>
            </div>

        </div>
    );
}