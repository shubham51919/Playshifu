import Image from "next/image"
import Link from "next/link"
import { Search, ShoppingCart, Heart, User, Menu, Star, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ProductCard from "@/components/product-card"
import AgeCategory from "@/components/age-category"
import CategoryCard from "@/components/category-card"
import ChatSupport from "@/components/chat-support"
import ToyShopCarousel from "@/components/banner-carousel"
import ProductListings from "@/components/product-listings"
import Footer from "@/components/Footer"
import TestimonialCarousel from "@/components/review-caroursel"
import MediaFeatureSection from "@/components/featured"

export default function Home() {
  const products = [
    {
      id: '1',
      image: '/images/card.png',
      title: 'Letters',
      price: 29.99,
      salePrice: 19.99,
      rating: 4.5
    },
    {
      id: '2',
      image: '/images/card.png',
      title: 'Smart Globe',
      price: 39.99,
      salePrice: 29.99,
      rating: 4.8
    },
    {
      id: '3',
      image: '/images/card.png',
      title: 'Puzzle Set',
      price: 24.99,
      salePrice: 18.99,
      rating: 4.7
    },
    {
      id: '4',
      image: '/images/card.png',
      title: 'STEM Kit',
      price: 49.99,
      salePrice: 39.99,
      rating: 4.9
    },
    {
      id: '5',
      image: '/images/card.png',
      title: 'Building Blocks',
      price: 34.99,
      salePrice: 24.99,
      rating: 4.6
    },
    // Add more products as needed
  ];
  return (
    <main className="flex min-h-screen flex-col bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#FFDD00] px-4 py-3">
        <div className="flex items-center justify-between w-full ">
          <div className="flex w-[20%] items-center gap-6">
            <Menu className="h-6 w-6" />
            <Image
              src="/images/logo.webp?height=30&width=100"
              alt="PlayKids Logo"
              width={200}
              height={30}
              className="h-8"
            />
          </div>
          <div className=" relative w-1/2 ">
            <Input placeholder="Search for toys, brands and more" className="pl-9 bg-white rounded-full h-10 w-full" />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <div className="flex items-center gap-12 justify-center w-[30%] flex justify-between">
            <div className="flex items-center gap-4">
              <Heart className="h-5 w-5" />
              <div className="">Wishlist</div>
            </div>
            <div className="flex items-center gap-4">
              <User className="h-5 w-5" />
              <div className="">Signin</div>
            </div>
            <div className="flex items-center gap-4">
              <ShoppingCart className="h-5 w-5" />
              <div className="">Cart</div>
            </div>
          </div>
        </div>

      </header>

      {/* Main Content */}
      <div className="flex-1">
        {/* Hero Banner */}
        <ToyShopCarousel />

        {/* Award Section */}
        <section className="px-4 py-5">
          <h2 className="font-bold text-lg mb-3">Multi Award winning toys</h2>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="flex flex-col items-center">
                <div className="flex items-center justify-center">
                  {/* <Star className="h-5 w-5 text-blue-500" /> */}
                  <img src={`/images/award${i}.png`} alt={`Award ${i}`} />
                </div>
                <span className="text-xs text-center">Award {i}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Shop by Age */}
        <section className="px-4 py-3 bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-lg">Shop by age</h2>
            <Link href="/ages" className="text-sm text-gray-500 flex items-center">
              See all <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <AgeCategory age="0-2" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="3-5" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="6-8" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="9-12" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="12+" color="bg-[#822382]" textColor="text-white" />
          </div>
        </section>

        {/* Product Listings */}
        <section>
          <ProductListings products={products} title="" />
        </section>

        {/* Shop by Caegory */}
        <section className="px-4 py-3 bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-lg">Shop by Category</h2>
            <Link href="/ages" className="text-sm text-gray-500 flex items-center">
              See all <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <AgeCategory age="0-2" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="3-5" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="6-8" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="9-12" color="bg-[#822382]" textColor="text-white" />
            <AgeCategory age="12+" color="bg-[#822382]" textColor="text-white" />
          </div>
        </section>


        <section className="px-4 py-3 bg-gray-50">
          {/* Product Listings */}
          <section>
            <ProductListings products={products} title="" />
          </section>
        </section>

        {/* Features Section */}
        <section className="px-4 py-5 bg-white">
          <div className="grid grid-cols-4 gap-2">
            {[
              { icon: "star", title: "Premium Quality" },
              { icon: "circle", title: "Fast Delivery" },
              { icon: "dollar", title: "Best Prices" },
              { icon: "shield", title: "Secure Payment" },
            ].map((feature, i) => (
              <div key={i} className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center mb-1">
                  <Star className="h-6 w-6 text-orange-500" />
                </div>
                <span className="text-xs text-center">{feature.title}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Deals and Discounts */}
        <section>
          <ProductListings products={products} title="" />
        </section>

        {/* Testimonials */}
        <section className="px-4 py-5 bg-white">
          <TestimonialCarousel />
        </section>

        {/* Media Mentions */}
        <section className="px-4 py-5 bg-white">
          <MediaFeatureSection />
        </section>

        {/* Partners */}
        <section className="px-4 py-5 bg-[#FFDD00] w-full">
          <p className="text-sm font-medium mb-3">Also available at</p>
          <div className="flex justify-between items-center">
            <Image src="/images/available1.png?height=30&width=80" alt="Amazon" className="border border-black border-[1.5px] rounded-lg" width={250} height={320} />
            <Image src="/images/available1.png?height=30&width=80" alt="Amazon" className="border border-black border-[1.5px] rounded-lg" width={250} height={320} />
            <Image src="/images/available1.png?height=30&width=80" alt="Amazon" className="border border-black border-[1.5px] rounded-lg" width={250} height={320} />
            <Image src="/images/available1.png?height=30&width=80" alt="Amazon" className="border border-black border-[1.5px] rounded-lg" width={250} height={320} />
            <Image src="/images/available1.png?height=30&width=80" alt="Amazon" className="border border-black border-[1.5px] rounded-lg" width={250} height={320} />

          </div>
        </section>

        {/* Chat Support */}
        <ChatSupport />
      </div>

      {/* Footer */}
      <Footer />
      {/* <footer className="bg-gray-100 px-4 py-5">
        <div className="mb-5">
          <h3 className="font-medium text-sm mb-2">Shop by category</h3>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>
              <Link href="/category/puzzles">Puzzles & Education</Link>
            </li>
            <li>
              <Link href="/category/support">Support</Link>
            </li>
          </ul>
        </div>

        <div className="mb-5">
          <h3 className="font-medium text-sm mb-2">Connect with us</h3>
          <div className="flex gap-3">
            <Link href="#" className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
              <Image src="/placeholder.svg?height=16&width=16" alt="Facebook" width={16} height={16} />
            </Link>
            <Link href="#" className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
              <Image src="/placeholder.svg?height=16&width=16" alt="Instagram" width={16} height={16} />
            </Link>
            <Link href="#" className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
              <Image src="/placeholder.svg?height=16&width=16" alt="Twitter" width={16} height={16} />
            </Link>
            <Link href="#" className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
              <Image src="/placeholder.svg?height=16&width=16" alt="YouTube" width={16} height={16} />
            </Link>
          </div>
        </div>

        <div className="flex gap-2 mb-5">
          <Image src="/placeholder.svg?height=30&width=40" alt="Visa" width={40} height={30} />
          <Image src="/placeholder.svg?height=30&width=40" alt="Mastercard" width={40} height={30} />
          <Image src="/placeholder.svg?height=30&width=40" alt="Amex" width={40} height={30} />
          <Image src="/placeholder.svg?height=30&width=40" alt="PayPal" width={40} height={30} />
        </div>

        <p className="text-xs text-gray-500 text-center">© 2023 PlayKids. All rights reserved.</p>
      </footer> */}
    </main>
  )
}
